#ifndef PROJECT_1_GAMEENGINEDRIVER_H
#define PROJECT_1_GAMEENGINEDRIVER_H

// function declaration
void testStartupPhase();

#endif //PROJECT_1_GAMEENGINEDRIVER_H
